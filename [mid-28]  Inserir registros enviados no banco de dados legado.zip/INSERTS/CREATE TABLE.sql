CREATE TABLE atividade
                      (
                       CODIGO    NUMBER       ,
                       DESCRICAO VARCHAR2(255)
                      );

CREATE TABLE base_legal_renegociacao
                                    (
                                     CODIGO        NUMBER       ,
                                     DESCRICAO_BRL VARCHAR2(255)
                                    );

CREATE TABLE categoria_emitente
                               (
                                CODIGO       NUMBER       ,
                                DESCRICAO    VARCHAR2(255),
                                DATA_INICIO  VARCHAR2(255),
                                DATA_FIM     VARCHAR2(255)         ,
                                VALOR_LIMITE NUMBER       ,
                                AREA_MAXIMA  NUMBER
                               );

CREATE TABLE cesta_safras
                         (
                           CODIGO    NUMBER       ,
                           DESCRICAO VARCHAR2(255)
                         );

CREATE TABLE ciclo_cultivar_proagro
                                   (
                                    CODIGO          NUMBER       ,
                                    DESCRICAO_CICLO VARCHAR2(255)
                                   );

CREATE TABLE consorcio
                      (
                       CODIGO    NUMBER       ,
                       DESCRICAO VARCHAR2(255)
                      );

CREATE TABLE empreendimento
                           (
                            CODIGO                  NUMBER       ,
                            DATA_INICIO             VARCHAR2(255),
                            DATA_FIM                VARCHAR2(255)         ,
                            FINALIDADE              VARCHAR2(255)         ,
                            ATIVIDADE               VARCHAR2(255)         ,
                            MODALIDADE              VARCHAR2(255),
                            PRODUTO                 VARCHAR2(255),
                            VARIEDADE               VARCHAR2(500)         ,
                            CESTA                   VARCHAR2(255),
                            ZONEAMENTO              VARCHAR2(255)         ,
                            UNIDADE_MEDIDA          VARCHAR2(255),
                            UNIDADE_MEDIDA_PREVISAO VARCHAR2(255),
                            CONSORCIO               VARCHAR2(255),
                            CEDULA_MAE              NUMBER       ,
                            CD_TIPO_CULTURA         NUMBER
                           );

CREATE TABLE empreendimento_aliquota
                                      (
                                       CODIGO      NUMBER       ,
                                       VALOR       NUMBER       ,
                                       DATA_INICIO VARCHAR2(255),
                                       DATA_FIM    VARCHAR2(255)
                                      );

CREATE TABLE encargos_financeiros_complementares
                                                (
                                                 CODIGO    NUMBER       ,
                                                 DESCRICAO VARCHAR2(255)
                                                );

CREATE TABLE evento_proagro
                            (
                             CODIGO      NUMBER       ,
                             NOME_EVENTO VARCHAR2(255)
                            );
                                       
CREATE TABLE fase_ciclo_producao
                                (
                                 CODIGO    NUMBER       ,
                                 DESCRICAO VARCHAR2(255)
                                );

CREATE TABLE finalidade
                        (
                         CODIGO    NUMBER       ,
                         DESCRICAO VARCHAR2(255)
                        );

CREATE TABLE fonte_recursos
                           (
                            CODIGO      NUMBER       ,
                            DESCRICAO   VARCHAR2(255),
                            DATA_INICIO VARCHAR2(255),
                            DATA_FIM    VARCHAR2(255)
                           );

CREATE TABLE fonte_recursos_taxa_juros
                                       (
                                        CODIGO      NUMBER       ,
                                        DESCRICAO   VARCHAR2(255),
                                        VALOR       NUMBER       ,
                                        DATA_INICIO VARCHAR2(255),
                                        DATA_FIM    VARCHAR2(255)
                                       );

CREATE TABLE fonte_recursos_uf
                                (
                                 CODIGO    NUMBER       ,
                                 DESCRICAO VARCHAR2(255),
                                 UF        CHAR(2)
                                );

CREATE TABLE grao_semente
                           (
                            CODIGO    NUMBER       ,
                            DESCRICAO VARCHAR2(255)
                           );

CREATE TABLE ifs_do_sicor
                          (
                           CNPJ_IF     VARCHAR2(255),
                           NOME_IF     VARCHAR2(255)         ,
                           SEGMENTO_IF VARCHAR2(255)
                          );

CREATE TABLE instancia_proagro
                               (
                                CODIGO    NUMBER       ,
                                DESCRICAO VARCHAR2(255)
                               );

CREATE TABLE instrumento_credito
                                 (
                                  CODIGO    NUMBER       ,
                                  DESCRICAO VARCHAR2(255),
                                  SIGLA     VARCHAR2(4)
                                 );

CREATE TABLE modalidade
                        (
                         CODIGO_FINALIDADE NUMBER       ,
                         NOME_FINALIDADE   VARCHAR2(255)         ,
                         CODIGO_ATIVIDADE  NUMBER       ,
                         NOME_ATIVIDADE    VARCHAR2(255)         ,
                         CODIGO_MODALIDADE NUMBER       ,
                         NOME_MODALIDADE   VARCHAR2(255)
                        );

CREATE TABLE motivo_desclassificacao
                                    (
                                     CODIGO    NUMBER,
                                     DESCRICAO VARCHAR2(255)
                                    );

CREATE TABLE motivo_exclusao
                             (
                             CODIGO    NUMBER       ,
                             DESCRICAO VARCHAR2(255)
                             );

CREATE TABLE municipios_sicor
                              (
                               COD_MUNICIPIO_CADMU NUMBER       ,
                               NOME_MUNICIPIO      VARCHAR2(255),
                               COD_MUNICIPIO_IBGE  NUMBER                ,
                               COD_UF              VARCHAR2(255),
                               NOME_UF             VARCHAR2(255),
                               COD_UF_IBGE         NUMBER
                              );

CREATE TABLE natureza_proagro
                             (
                              CODIGO             NUMBER       ,
                              DESCRICAO_NATUREZA VARCHAR2(255)
                             );

CREATE TABLE prazo_operacao
                            (
                             CODIGO_FINALIDADE NUMBER       ,
                             FINALIDADE        VARCHAR2(255),
                             CODIGO_ATIVIDADE  NUMBER       ,
                             ATIVIDADE         VARCHAR2(255),
                             PRAZO_MINIMO      VARCHAR2(255),
                             PRAZO_MAXIMO      VARCHAR2(255)
                            );

CREATE TABLE prazo_operacao_fonte_recursos
                                           (
                                            CODIGO_FINALIDADE     NUMBER       ,
                                            NOME_FINALIDADE       VARCHAR2(255),
                                            CODIGO_ATIVIDADE      NUMBER       ,
                                            NOME_ATIVIDADE        VARCHAR2(255),
                                            CODIGO_FONTE_RECURSOS NUMBER       ,
                                            NOME_FONTE_RECURSOS   VARCHAR2(255),
                                            PRAZO_MINIMO          VARCHAR2(255),
                                            PRAZO_MAXIMO          VARCHAR2(255)
                                           );

CREATE TABLE prazo_operacao_modalidade
                                      (
                                       CODIGO_FINALIDADE NUMBER,
                                       NOME_FINALIDADE   VARCHAR2(255),
                                       CODIGO_ATIVIDADE  NUMBER,
                                       NOME_ATIVIDADE    VARCHAR2(255),
                                       CODIGO_MODALIDADE NUMBER,
                                       NOME_MODALIDADE   VARCHAR2(255),
                                       PRAZO_MINIMO      VARCHAR2(255),
                                       PRAZO_MAXIMO      VARCHAR2(255)
                                      );

CREATE TABLE prazo_operacao_programa
                                     (
                                       CODIGO_FINALIDADE NUMBER       ,
                                       NOME_FINALIDADE   VARCHAR2(255),
                                       CODIGO_ATIVIDADE  NUMBER       ,
                                       NOME_ATIVIDADE    VARCHAR2(255),
                                       CODIGO_PROGRAMA   NUMBER       ,
                                       PROGRAMA          VARCHAR2(255),
                                       PRAZO_MINIMO      VARCHAR2(255),
                                       PRAZO_MAXIMO      VARCHAR2(255)
                                     );

CREATE TABLE produto
                     (
                      CODIGO      NUMBER       ,
                      DESCRICAO   VARCHAR2(255),
                      DATA_INICIO VARCHAR2(255),
                      DATA_FIM    VARCHAR2(255)
                     );

CREATE TABLE programa
                      (
                       CODIGO        NUMBER       ,
                       DESCRICAO     VARCHAR2(255),
                       DATA_INICIO   VARCHAR2(255),
                       DATA_FIM      VARCHAR2(255),
                       FINANCIAMENTO VARCHAR2(255)
                      );

CREATE TABLE programa_aliquota
                               (
                                CODIGO      NUMBER       ,
                                DESCRICAO   VARCHAR2(255),
                                VALOR       NUMBER       ,
                                DATA_INICIO VARCHAR2(255),
                                DATA_FIM    VARCHAR2(255)
                               );

CREATE TABLE programa_fonte_recursos
                                     (
                                      CODIGO_PROGRAMA    NUMBER       ,
                                      DESCRICAO_PROGRAMA VARCHAR2(255),
                                      CODIGO_FONTE       NUMBER       ,
                                      DESCRICAO_FONTE    VARCHAR2(255)
                                     );

CREATE TABLE programa_modalidade
                                 (
                                  CODIGO_PROGRAMA    NUMBER       ,
                                  DESCRICAO_PROGRAMA VARCHAR2(255),
                                  CODIGO_FINALIDADE  NUMBER       ,
                                  FINALIDADE         VARCHAR2(255),
                                  CODIGO_ATIVIDADE   NUMBER       ,
                                  ATIVIDADE          VARCHAR2(255),
                                  CODIGO_MODALIDADE  NUMBER       ,
                                  MODALIDADE         VARCHAR2(255)
                                 );

CREATE TABLE programa_produto
                              (
                               CODIGO_PROGRAMA    NUMBER       ,
                               DESCRICAO_PROGRAMA VARCHAR2(255),
                               CODIGO_PRODUTO     NUMBER       ,
                               DESCRICAO_PRODUTO  VARCHAR2(255)
                              );

CREATE TABLE programa_taxa_juros
                                 (
                                  CODIGO      NUMBER       ,
                                  DESCRUCAO   VARCHAR2(255),
                                  VALOR       NUMBER       ,
                                  DATA_INICIO VARCHAR2(255),
                                  DATA_FIM    VARCHAR2(255)
                                 );

CREATE TABLE programa_uf
                         (
                          CODIGO    NUMBER       ,
                          DESCRICAO VARCHAR2(255),
                          UF        CHAR(2)
                         );

CREATE TABLE sistema_producao_empreendimento
                                             (
                                              EMPREENDIMENTO                   NUMBER       ,
                                              CODIGO_TIPO_AGROPECUARIA         VARCHAR2(255),
                                              TIPO_AGROPECUARIA                VARCHAR2(255),
                                              CODIGO_TIPO_INTEGRACAO_CONSORCIO VARCHAR2(255),
                                              TIPO_INTEGRACAO_CONSORCIO        VARCHAR2(255),
                                              CODIGO_GRAO_SEMENTE              VARCHAR2(255),
                                              GRAO_SEMENTE                     VARCHAR2(255),
                                              CODIGO_TIPO_IRRIGACAO            VARCHAR2(255),
                                              TIPO_IRRIGACAO                   VARCHAR2(255),
                                              CODIGO_TIPO_CULTIVO_EXPLORACAO   VARCHAR2(255),
                                              TIPO_CULTIVO_EXPLORACAO          VARCHAR2(255),
                                              CODIGO_FASE_CICLO_PRODUCAO       VARCHAR2(255),
                                              FASE_CICLO_PRODUCAO              VARCHAR2(255),
                                              CODIGO_ANTIGO                    VARCHAR2(255)
                                             );

CREATE TABLE situacao_operacao
                               (
                                CODIGO    NUMBER       ,
                                DESCRICAO VARCHAR2(255)
                               );

CREATE TABLE status_cop_proagro
                                (
                                 CODIGO    NUMBER       ,
                                 DESCRICAO VARCHAR2(255)
                                );

CREATE TABLE status_parcela_proagro
                                    (
                                     CODIGO    NUMBER       ,
                                     DESCRICAO VARCHAR2(255)
                                    );

CREATE TABLE sub_programas
                           (
                            CODIGO_SUBPROGRAMA    NUMBER       ,
                            DESCRICAO_SUBPROGRAMA VARCHAR2(255),
                            VL_TAXA_JUROS         NUMBER       ,
                            CODIGO_PROGRAMA       NUMBER
                           );

CREATE TABLE tipo_agropecuaria
                               (
                                CODIGO    NUMBER       ,
                                DESCRICAO VARCHAR2(255)
                               );

CREATE TABLE tipo_beneficiario
                               (
                                CODIGO    NUMBER       ,
                                DESCRICAO VARCHAR2(255)
                               );

CREATE TABLE tipo_bonus
                        (
                         CODIGO    NUMBER       ,
                         DESCRICAO VARCHAR2(255)
                        );

CREATE TABLE tipo_clima
                        (
                         TCL_ID                      NUMBER       ,
                         TCL_NM_OPERADOR_ATUALIZACAO VARCHAR2(255),
                         TCL_DH_ULTIMA_INCLUSAO      VARCHAR2(255),
                         TCL_CD                      NUMBER       ,
                         TCL_DS                      VARCHAR2(255)
                        );

CREATE TABLE tipo_cultivo
                          (
                           CODIGO    NUMBER       ,
                           DESCRICAO VARCHAR2(255)
                          );

CREATE TABLE tipo_cultura
                          (
                           CODIGO    NUMBER       ,
                           DESCRICAO VARCHAR2(255)
                          );

CREATE TABLE tipo_garantia_empreendimento
                                          (
                                           CODIGO    NUMBER       ,
                                           DESCRICAO VARCHAR2(255)
                                          );

CREATE TABLE tipo_integracao
                             (
                              CODIGO    NUMBER       ,
                              DESCRICAO VARCHAR2(255)
                             );

CREATE TABLE tipo_irrigacao
                            (
                             CODIGO    NUMBER       ,
                             DESCRICAO VARCHAR2(255)
                            );

CREATE TABLE tipo_manejo
                         (
                          CODIGO    NUMBER       ,
                          DESCRICAO VARCHAR2(255)
                         );

CREATE TABLE tipo_solo_proagro
                               (
                                CODIGO_TIPO_SOLO    NUMBER       ,
                                DESCRICAO_TIPO_SOLO VARCHAR2(255)
                               );

CREATE TABLE unidade_medida
                            (
                             UNM_DS                     VARCHAR2(255),
                             UNM_SL                     VARCHAR2(255),
                             UNM_CD_TIPO_UNIDADE_MEDIDA VARCHAR2(255),
                             UNM_ID                     NUMBER
                            );

CREATE TABLE variedade_produto
                               (
                                CODIGO     NUMBER       ,
                                DESCRICAO  VARCHAR2(500),
                                DATA_INCIO VARCHAR2(255),
                                DATA_FIM   VARCHAR2(255)
                               );

CREATE TABLE zoneamento
                        (
                         CODIGO    NUMBER       ,
                         DESCRICAO VARCHAR2(255)
                        );



