INSERT INTO ADMIN.MOTIVO_EXCLUSAO (CODIGO, DESCRICAO) VALUES (1, 'Cadastramento Indevido');
INSERT INTO ADMIN.MOTIVO_EXCLUSAO (CODIGO, DESCRICAO) VALUES (2, 'Duplicidade de Opera��o');
INSERT INTO ADMIN.MOTIVO_EXCLUSAO (CODIGO, DESCRICAO) VALUES (3, 'Desist�ncia do Financiamento verificada antes da libera��o da primeira parcela do cr�dito');
INSERT INTO ADMIN.MOTIVO_EXCLUSAO (CODIGO, DESCRICAO) VALUES (5, 'Falta de libera��o de recursos');
INSERT INTO ADMIN.MOTIVO_EXCLUSAO (CODIGO, DESCRICAO) VALUES (66, 'Exclus�o por recomposi��o via COR0004');
INSERT INTO ADMIN.MOTIVO_EXCLUSAO (CODIGO, DESCRICAO) VALUES (67, 'Cancelamento de exclus�o via COR0004');
INSERT INTO ADMIN.MOTIVO_EXCLUSAO (CODIGO, DESCRICAO) VALUES (6, 'Opera��o sem lista de cooperados/integrados');
