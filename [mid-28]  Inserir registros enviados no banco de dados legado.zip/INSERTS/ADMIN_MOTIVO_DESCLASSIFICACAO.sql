INSERT INTO ADMIN.MOTIVO_DESCLASSIFICACAO (CODIGO, DESCRICAO) VALUES (1, 'Aplicação de recursos em atividade diversa daquelas previstas na regulamentação do crédito rural');
INSERT INTO ADMIN.MOTIVO_DESCLASSIFICACAO (CODIGO, DESCRICAO) VALUES (2, 'Obtenção de crédito acima dos limites regulamentares mediante documento ou declaração falsos');
INSERT INTO ADMIN.MOTIVO_DESCLASSIFICACAO (CODIGO, DESCRICAO) VALUES (3, 'Obtenção de um ou mais financiamentos para aplicação em empreendimento ou item do orçamento já financiado');
INSERT INTO ADMIN.MOTIVO_DESCLASSIFICACAO (CODIGO, DESCRICAO) VALUES (4, 'Obtenção de crédito mediante orçamento de valor superior ao custo normal ou de mercado do empreendimento');
INSERT INTO ADMIN.MOTIVO_DESCLASSIFICACAO (CODIGO, DESCRICAO) VALUES (5, 'Obtenção de crédito mediante interposição de outros mutuários, inclusive partes relacionadas');
INSERT INTO ADMIN.MOTIVO_DESCLASSIFICACAO (CODIGO, DESCRICAO) VALUES (6, 'Obtenção de crédito para aplicação em empreendimento localizado em área cujo uso seja vedado pela legislação ou regulamentação aplicáveis ao crédito rural');
INSERT INTO ADMIN.MOTIVO_DESCLASSIFICACAO (CODIGO, DESCRICAO) VALUES (7, 'Obtenção de crédito por pessoa natural ou jurídica não enquadrada como beneficiária do crédito rural ou legalmente impedida de ter acesso ao financiamento');
INSERT INTO ADMIN.MOTIVO_DESCLASSIFICACAO (CODIGO, DESCRICAO) VALUES (8, 'Acesso irregular à subvenção econômica ou ao enquadramento indevido no Proagro (ITEM CANCELADO)');
INSERT INTO ADMIN.MOTIVO_DESCLASSIFICACAO (CODIGO, DESCRICAO) VALUES (999, 'Outro');
